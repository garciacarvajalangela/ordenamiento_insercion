
package ordenamiento;


public class Ordenamiento {

    public static void main(String[] args) {
        new FrmOrdenamiento().setVisible(true);
    }
    
}
