package ordenamiento;

public enum CriterioOrdenamiento {
    NOMBRECOMPLETO_DOCUMENTO,
    DOCUMENTO_NOMBRECOMPLETO
}
